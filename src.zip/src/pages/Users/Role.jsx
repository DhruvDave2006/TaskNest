import React from 'react'

function Role() {
  return (
    <div>This is Role page</div>
  )
}

export default Role