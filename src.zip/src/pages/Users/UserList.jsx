import React from 'react'

function UserList() {
  return (
    <div>This is UserList page</div>
  )
}

export default UserList