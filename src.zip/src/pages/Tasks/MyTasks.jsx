import React from 'react'

function MyTasks() {
  return (
    <div>This is MyTasks page</div>
  )
}

export default MyTasks